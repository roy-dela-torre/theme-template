<?php
/*
Plugin Name: Image Optimizer Plugin
Description: Upload a ZIP of JPGs/PNGs (>1MB), optimize them, and get a new ZIP.
Version: 1.1
Author: Roy de la Torre
*/

add_shortcode('image_optimizer_form', 'image_optimizer_form');

function image_optimizer_form()
{
    ob_start(); ?>
    <div class="form_container">
        <p>This function processes file uploads ensuring that the uploaded file is in zip format. FAdditionally, if the file is an image, only JPG and PNG formats are allowed.</p>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="zip_file" accept=".zip" required>
            <button type="submit" name="optimize_zip">Optimize Images</button>
        </form>
    </div>
<?php

    if (isset($_POST['optimize_zip']) && isset($_FILES['zip_file'])) {
        $upload_dir = wp_upload_dir();
        $temp_dir = $upload_dir['basedir'] . '/image_optimizer_' . time();
        mkdir($temp_dir, 0777, true);

        $zip_path = $temp_dir . '/' . basename($_FILES['zip_file']['name']);
        move_uploaded_file($_FILES['zip_file']['tmp_name'], $zip_path);

        $zip = new ZipArchive;
        if ($zip->open($zip_path) === TRUE) {
            $zip->extractTo($temp_dir . '/extracted');
            $zip->close();

            $output_dir = $temp_dir . '/optimized';
            mkdir($output_dir);

            foreach (scandir($temp_dir . '/extracted') as $file) {
                if (preg_match('/\.(jpg|jpeg|png)$/i', $file)) {
                    $source = $temp_dir . '/extracted/' . $file;
                    if (filesize($source) > 1024 * 1024) { // Only optimize if >1MB
                        $dest = $output_dir . '/' . $file;
                        optimize_image($source, $dest);
                    }
                }
            }

            $zip_output = $temp_dir . '/optimized_images.zip';
            $zip = new ZipArchive;
            if ($zip->open($zip_output, ZipArchive::CREATE) === TRUE) {
                foreach (scandir($output_dir) as $file) {
                    if (in_array($file, array('.', '..'))) continue;
                    $zip->addFile($output_dir . '/' . $file, $file);
                }
                $zip->close();

                $zip_url = $upload_dir['baseurl'] . str_replace($upload_dir['basedir'], '', $zip_output);
                echo "<p><a href='$zip_url' download>Download Optimized Images</a></p>";
            }
        }
    }

    return ob_get_clean();
}

function optimize_image($input, $output)
{
    $quality = 60;
    $ext = strtolower(pathinfo($input, PATHINFO_EXTENSION));
    if ($ext === 'jpg' || $ext === 'jpeg') {
        $image = imagecreatefromjpeg($input);
        if ($image) {
            imagejpeg($image, $output, $quality);
            imagedestroy($image);
        }
    } elseif ($ext === 'png') {
        $image = imagecreatefrompng($input);
        if ($image) {
            // Convert quality: 0 (no compression) - 9 (max compression)
            $png_quality = 9 - round($quality / 10);
            imagepng($image, $output, $png_quality);
            imagedestroy($image);
        }
    }
}
function image_optimizer_plugin_enqueue_styles()
{
    wp_enqueue_style(
        'image-optimizer-plugin-style',
        plugins_url('image-optimizer-plugin.css', __FILE__),
        array(),
        '1.1'
    );
}
add_action('wp_enqueue_scripts', 'image_optimizer_plugin_enqueue_styles');
